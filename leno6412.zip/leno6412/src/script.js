// Handle contact form submission

function submitForm() {

  const response = document.getElementById("response");

  response.textContent = "✅ Thank you! Your message has been sent.";

  response.style.color = "green";

  

  // Clear form fields

  document.getElementById("name").value = "";

  document.getElementById("email").value = "";

  document.getElementById("message").value = "";

  

  return false; // Prevent page reload

}

// Smooth scrolling effect for navigation links

document.querySelectorAll('nav a').forEach(anchor => {

  anchor.addEventListener("click", function(e) {

    e.preventDefault();

    document.querySelector(this.getAttribute("href")).scrollIntoView({

      behavior: "smooth"

    });

  });

});